import java.util.*;
import java.util.concurrent.*;

public class Sample {  
  public static final int MAX = 1000000; //we could not get above 5000 on my machine with threads
  
  public static void doWork() {
    try { Thread.sleep(2000); } catch(Exception ex) {}
  }

  public static void main(String[] args) throws Exception {
    Thread th = null;
    
    boolean useVirtualThreads = Math.random() > 0.5;
    
    String message = useVirtualThreads ? "virtual" : "good old";
    
    System.out.println("using " + message + " thnreads");
    
    for(int i = 0; i < MAX; i++) {
      if(useVirtualThreads) {
        th = Thread.startVirtualThread(Sample::doWork);        
      } else {
        th = new Thread(Sample::doWork);
        th.start();
      }
    }
    
    th.join();
    
    System.out.println("done");
  }
}