import java.util.*;
import java.net.*;

public class Sample {  
  public static void getResponse() {          
    var url = "http://httpstat.us/200";

    System.out.println("sending request from: " + Thread.currentThread());
    try(Scanner scanner = new Scanner(new URL(url).openStream())) {
      System.out.println(scanner.nextLine());
    } catch(Exception ex) {
      System.out.println(ex.getMessage());
    } finally {
      System.out.println("received response from: " + Thread.currentThread());
    }
  } 
  
  public static void main(String[] args) throws Exception {
    Thread th1 = new Thread(Sample::getResponse);
    th1.start();
    
    th1.join();

    Thread th2 = Thread.startVirtualThread(Sample::getResponse);
    
    th2.join();
  }
}